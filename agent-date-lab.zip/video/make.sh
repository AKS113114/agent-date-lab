#!/usr/bin/env bash
set -e
W=1280; H=720
make(){ name=$1; dur=$2; title=$3; body=$4; ffmpeg -y -f lavfi -i "color=c=0x0b0b10:s=${W}x${H}:d=${dur}" -vf "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='AGENT DATE LAB':x=70:y=55:fontsize=24:fontcolor=0xff4f9a,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${title}':x=70:y=150:fontsize=52:fontcolor=white,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='${body}':x=70:y=245:fontsize=30:fontcolor=0xd7d7e0:line_spacing=14" -r 30 -t $dur -pix_fmt yuv420p "video/$name.mp4" >/dev/null 2>&1; }
make 01 8 "30 public people" "LinkedIn + public Instagram pairs.  Source-grounded agents, not invented biographies."
make 02 12 "Agent profile: Ali Abdaal" "Needs: curiosity, warmth, shared energy.   Interests: productivity, education, books, creativity.  |  Two-source grounding: LinkedIn + Instagram."
make 03 18 "Agents are actually dating" "ALI AGENT: I optimize for curiosity, ease and a little adventure.  |  MATCH AGENT: Then let's choose a low-pressure plan and test the overlap.  |  ALI AGENT: Good. I care more about how the conversation flows than a perfect resume."
make 04 14 "Ranking every candidate" "1  Simon Sinek        86%   leadership · purpose  |  2  James Clear         82%   habits · learning  |  3  Lenny Rachitsky     79%   product · community  |    |  Explainable score: shared public interests + conversation signal."
make 05 8 "Try your own sources" "Paste one public LinkedIn URL + one public Instagram URL.  |  The production adapter can fetch, extract, analyze, date, and rank."
printf "file 'video/01.mp4'  |  file 'video/02.mp4'  |  file 'video/03.mp4'  |  file 'video/04.mp4'  |  file 'video/05.mp4'  |  " > video/list.txt
ffmpeg -y -f concat -safe 0 -i video/list.txt -c copy video/agent-date-demo.mp4 >/dev/null 2>&1
rm video/0*.mp4 video/list.txt
